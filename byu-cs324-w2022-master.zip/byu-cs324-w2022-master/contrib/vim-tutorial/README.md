# Learning Vim

From a CS lab machine, run the following:

```
vimtutor
```
